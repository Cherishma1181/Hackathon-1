package org.example.gitams_bookstore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GitamsBookstoreApplication {

    public static void main(String[] args) {
        SpringApplication.run(GitamsBookstoreApplication.class, args);
    }

}
