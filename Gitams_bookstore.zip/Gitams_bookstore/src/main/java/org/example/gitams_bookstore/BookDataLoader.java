package org.example.gitams_bookstore;


import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BookDataLoader {

    @Bean
    ApplicationRunner init(BookRepository repository) {
        return args -> {
            repository.save(new Book("Clean Code", "Robert C. Martin", "A Handbook of Agile Software Craftsmanship", "seniors", 10));
            repository.save(new Book("Effective Java", "Joshua Bloch", "Best practices for the Java platform", "seniors", 8));
            repository.save(new Book("Introduction to Algorithms", "Thomas H. Cormen", "Comprehensive textbook on algorithms", "juniors", 15));
            repository.save(new Book("The Pragmatic Programmer", "Andrew Hunt", "From Journeyman to Master", "seniors", 5));
            repository.save(new Book("Artificial Intelligence: A Modern Approach", "Stuart Russell", "Comprehensive AI textbook", "juniors", 12));
        };
    }
}